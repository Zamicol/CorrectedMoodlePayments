function displayText (selectTag) {
	if (selectTag == "Yes") {
		document.getElementById("DiscountedView").style.display = "block";
	} else {
		document.getElementById("DiscountedView").style.display = "none";
}