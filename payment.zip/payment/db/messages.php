<?php
/**

 * This plugin allows you to set up a course shop and shopping cart
 * @package    enrol_payment
 */

/**
 * upgrade from old version
 */

defined('MOODLE_INTERNAL') || die();

$messageproviders = array(
    'payment_enrolment' => array(),
);
